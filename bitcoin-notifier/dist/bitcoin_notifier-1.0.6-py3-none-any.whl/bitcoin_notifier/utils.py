#! /usr/bin/env python

import json
import requests
import time
from datetime import datetime

from requests import Session

ifttt_webhook_url = 'https://maker.ifttt.com/trigger/{}/with/key/m2syzMN9J62HA9Id46Z63e3wvUkpdHj-nDulcfmEpuy'


def get_latest_bitcoin_price():
    url = 'https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest'
    headers = {
        'Accepts': 'application/json',
        'X-CMC_PRO_API_KEY': '14d8fff4-16d8-4b5e-84d6-0bc99ea1b45d',
    }

    session = Session()
    session.headers.update(headers)
    try:
        response = session.get(url)
        data = json.loads(response.text)
    except:
        print("Error Occurred!!!")
    print("Current BTC price : ", float(data['data'][0]['quote']['USD']['price']))
    return float(data['data'][0]['quote']['USD']['price'])


def post_ifttt_webhook(event, value):
    data = {'value1': value}
    ifttt_event_url = ifttt_webhook_url.format(event)
    requests.post(ifttt_event_url, json=data)
    print("Triggering event : ", ifttt_event_url)


def format_bitcoin_history(bitcoin_history):
    rows = []
    for bitcoin_price in bitcoin_history:
        date = bitcoin_price['date'].strftime('%d.%m.%Y %H:%M')
        price = bitcoin_price['price']
        row = '{}: $<b>{}</b>'.format(date, price)
        rows.append(row)

    return '<br>'.join(rows)


def run(BITCOIN_PRICE_THRESHOLD, interval):
    bitcoin_history = []
    threshold = float(BITCOIN_PRICE_THRESHOLD[0])
    time_interval = float(interval[0])
    while True:
        price = get_latest_bitcoin_price()
        date = datetime.now()
        bitcoin_history.append({'date': date, 'price': price})

        if price < threshold:
            post_ifttt_webhook('bitcoin_price_emergency', price)

        if len(bitcoin_history) == 5:
            post_ifttt_webhook('bitcoin_price_update',
                               format_bitcoin_history(bitcoin_history))
            bitcoin_history = []

        time.sleep((time_interval / 10) * 60)
