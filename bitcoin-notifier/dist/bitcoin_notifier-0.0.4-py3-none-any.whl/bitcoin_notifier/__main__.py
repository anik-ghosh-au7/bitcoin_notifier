#!/usr/bin/python3

from bitcoin_notifier.cli import main
main()
