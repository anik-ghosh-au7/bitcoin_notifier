#! /usr/bin/env python

import argparse
from .utils import *


def main():
    parser = argparse.ArgumentParser(description="Bitcoin Notifier")

    parser.add_argument("-i", "--interval", type=int, nargs=1,
                        metavar="interval", default=[1], help="Time interval in minutes")

    parser.add_argument("-t", "--threshold", type=int, nargs=1,
                        metavar="threshold", default=[1], help="Threshold in USD")

    args = parser.parse_args()

    print('Running Application with time interval of ', args.interval[0], ' and threshold = $', args.threshold[0])
    run(args.threshold, args.interval)


if __name__ == "__main__":
    main()